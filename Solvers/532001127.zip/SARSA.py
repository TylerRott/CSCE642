# Licensing Information:  You are free to use or extend this codebase for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) inform Guni Sharon at 
# guni@tamu.edu regarding your usage (relevant statistics is reported to NSF).
# The development of this assignment was supported by NSF (IIS-2238979).
# Contributors:
# The core code base was developed by Guni Sharon (guni@tamu.edu).

from collections import defaultdict
import numpy as np
from Solvers.Abstract_Solver import AbstractSolver
from lib import plotting


class Sarsa(AbstractSolver):
    def __init__(self, env, eval_env, options):
        assert str(env.observation_space).startswith("Discrete"), (
            str(self) + " cannot handle non-discrete state spaces"
        )
        assert str(env.action_space).startswith("Discrete") or str(
            env.action_space
        ).startswith("Tuple(Discrete"), (
            str(self) + " cannot handle non-discrete action spaces"
        )
        super().__init__(env, eval_env, options)
        # The final action-value function.
        # A nested dictionary that maps state -> (action -> action-value).
        self.Q = defaultdict(lambda: np.zeros(env.action_space.n))

    def train_episode(self):
        """
        Run one episode of the SARSA algorithm: On-policy TD control.

        Use:
            self.env: OpenAI environment.
            self.epsilon_greedy(state): returns the epsilon-greedy action probabilities for 'state'
            self.sample(probs): samples an action from a probability vector
            self.options.steps: number of steps per episode
            self.options.gamma: Gamma discount factor.
            self.options.alpha: TD learning rate.
            self.Q[state][action]: q value for ('state', 'action')
            self.options.epsilon: Chance the sample a random action. Float betwen 0 and 1.

        """

        # Reset the environment
        state, dontCare = self.env.reset()
        action_probs = self.epsilon_greedy(state)
        action = self.sample(action_probs)

        for i in range(self.options.steps):
            next_state, reward, done, _ = self.step(action) #get next step and rewards

            next_action_probs = self.epsilon_greedy(next_state) #probability
            next_action = self.sample(next_action_probs)

            td_target = reward + (1.0 - float(done)) * self.options.gamma * self.Q[next_state][next_action] #formula from class
            self.Q[state][action] += self.options.alpha * (td_target - self.Q[state][action]) #add to q based on formula

            state = next_state #next
            action = next_action
            if done:
                break

    def pull_updates(self):
        raise NotImplementedError

    def __str__(self):
        return "Sarsa"

    def create_greedy_policy(self):
        """
        Creates a greedy policy based on Q values.

        Returns:
            A function that takes a state as input and returns a greedy action.
        """

        def policy_fn(state):
            q_values = self.Q[state]
            if len(q_values) == 0:
                return 0
            return int(np.argmax(q_values))

        return policy_fn

    def epsilon_greedy(self, state):
        """
        Compute the epsilon-greedy action probabilities for 'state', based on
        the current Q-values and epsilon.

        Note: this returns pi(.|s) as a vector, NOT a sampled action. Use
        self.sample(probs) when you need to act on it.

        Use:
            self.env.action_space.n: the size of the action space
            np.argmax(self.Q[state]): action with highest q value
        Returns:
            Probability of taking actions as a vector where each entry is the probability of taking that action
        """
        nA = self.env.action_space.n
        q_values = self.Q[state]
        best_action = int(np.argmax(q_values))
        action_probs = np.full(nA, self.options.epsilon / nA, dtype=float)
        action_probs[best_action] += 1.0 - self.options.epsilon
        return action_probs

    def plot(self, stats, smoothing_window=20, final=False):
        plotting.plot_episode_stats(stats, smoothing_window, final=final)
